export interface Profile {
  id: string;
  username: string;
  display_name: string;
  balance: number;
  is_admin: boolean;
  created_at: string;
}

export type IdeaStatus = 'アイデア募集' | '制作中' | '提出中' | '販売中';

export interface ProfileLite {
  username: string;
  display_name: string;
}

export interface Comment {
  id: number;
  idea_id: number;
  user_id: string;
  content: string;
  created_at: string;
  author?: ProfileLite;
}

export interface Idea {
  id: number;
  title: string;
  description: string;
  genre: string;
  image_url: string;
  images: string[];
  status: IdeaStatus;
  creator_id: string;
  modeler_id: string | null;
  creator_share: number;
  modeler_share: number;
  price_physical: number;
  price_digital: number;
  mfg_cost: number;
  size_tier: 'S' | 'M' | 'L' | 'XL';
  total_sales: number;
  platform_fee: number;
  creator_reward: number;
  modeler_reward: number;
  stl_path: string | null;
  delete_requested_by: string | null;
  created_at: string;
  comment_count?: number | { count: number }[] | null;
  rating_stats?: { avg: number | null; count: number }[] | null;
  creator?: ProfileLite | null;
  modeler?: ProfileLite | null;
}

export interface Order {
  id: number;
  user_id: string;
  idea_id: number;
  item_type: 'physical' | 'digital';
  price: number;
  fulfillment_fee: number;
  shipping_status: string;
  tracking_number: string;
  shipping_name: string;
  shipping_postal: string;
  shipping_address: string;
  shipping_phone: string;
  partner_status: string;
  partner_order_id: string;
  ordered_at: string | null;
  created_at: string;
  idea?: { title: string; stl_path?: string | null } | null;
  buyer?: ProfileLite | null;
}

export interface ExchangeRequest {
  id: number;
  user_id: string;
  exchange_type: string;
  amount: number;
  status: '未処理' | '完了';
  gift_code: string;
  created_at: string;
  requester?: ProfileLite | null;
}

export interface BalanceEntry {
  id: number;
  amount: number;
  type: string;
  expires_at: string | null;
  created_at: string;
}

export interface Announcement {
  id: number;
  title: string;
  body: string;
  is_active: boolean;
  created_at: string;
}

export interface Notification {
  id: number;
  user_id: string;
  title: string;
  body: string;
  created_at: string;
}

export interface GiftStock {
  id: number;
  exchange_type: string;
  amount: number;
  code: string;
  used_by: string | null;
  used_at: string | null;
  created_at: string;
}

export interface MyStats {
  rating_count: number;
  rating_avg: number;
  total_sales: number;
}

export const fmtYen = (n: number) => n.toLocaleString('ja-JP');

export const fmtDate = (iso: string) => (iso ? iso.slice(5, 16).replace('T', ' ') : '');
